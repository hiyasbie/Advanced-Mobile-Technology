package au.edu.jcu.cp3406.converter;

import android.widget.Button;
import android.widget.TextView;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.renderscript.Sampler;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

import java.util.Locale;

import javax.xml.transform.Result;

public class MainActivity<value, enter, constant> extends AppCompatActivity {

    RadioButton frIn, frCm, frFt, frM, frMl, frKl;
    RadioButton toIn, toCm, toFt, toM, toMl, toKl;
    Button button;
    TextView enter;
    TextView convert;
    double constant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        convert = findViewById(R.id.converted);
        button = findViewById(R.id.convertButton);
        enter = findViewById(R.id.Entered);
        frIn = findViewById(R.id.fromIn);toIn = findViewById(R.id.toIn);
        frCm = findViewById(R.id.fromCm);toCm = findViewById(R.id.toCm);
        frFt = findViewById(R.id.fromFoot);toFt = findViewById(R.id.toFoot);
        frM = findViewById(R.id.fromMeter);toM = findViewById(R.id.toMeter);
        frMl = findViewById(R.id.fromMile);toMl = findViewById(R.id.toMile);
        frKl = findViewById(R.id.fromKilometer);toKl = findViewById(R.id.toKilometer);

        if (savedInstanceState != null) {
            String valueString = savedInstanceState.getString("edit text");
            enter.setText(valueString);
        }
    }

    public void convert(View view) {
        double number = Double.parseDouble(enter.getText().toString());
         //Inch
         if (frIn.isChecked() & toIn.isChecked()){
             constant = 1;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if(frIn.isChecked() & toCm.isChecked()){
            constant = 2.54;
            double value = number * constant;
            String result = String.format(Locale.getDefault(), "%.5f", value);
            convert.setText(result);
         }
         else if(frIn.isChecked() & toFt.isChecked()){
             constant = 0.0833333;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frIn.isChecked() & toM.isChecked()) {
             constant = 0.0254;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         } else if (frIn.isChecked() & toMl.isChecked()) {
            constant = 1.5783e-5;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         } else if (frIn.isChecked() & toKl.isChecked()) {
             constant = 2.54e-5;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
            //CM
        else if (frCm.isChecked() & toIn.isChecked()){
            constant = 0.393701;
            double value = number * constant;
            String result = String.format(Locale.getDefault(), "%.5f", value);
            convert.setText(result);
        }
         else if (frCm.isChecked() & toCm.isChecked()){
             constant = 1;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frCm.isChecked() & toFt.isChecked()) {
             constant = 0.0328084;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
        else if(frCm.isChecked() & toM.isChecked()){
            constant = 0.01;
            double value = number * constant;
            String result = String.format(Locale.getDefault(), "%.5f", value);
            convert.setText(result);
        }
        else if (frCm.isChecked() & toMl.isChecked()) {
            constant = 6.2137e-6;
            double value = number * constant;
            String result = String.format(Locale.getDefault(), "%.5f", value);
            convert.setText(result);
        } else if (frCm.isChecked() & toKl.isChecked()) {
             constant = 1e-5;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
        //Foot
         else if (frFt.isChecked() & toIn.isChecked()){
             constant = 12;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if(frFt.isChecked() & toCm.isChecked()){
             constant = 30.48;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if(frFt.isChecked() & toFt.isChecked()){
             constant = 1;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if(frFt.isChecked() & toM.isChecked()){
             constant = 0.3048;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if(frFt.isChecked() & toMl.isChecked()){
             constant = 0.000189394;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frFt.isChecked() & toKl.isChecked()) {
             constant = 0.0003048;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         //Meter
         else if(frM.isChecked() & toIn.isChecked()){
             constant = 39.3701;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if(frM.isChecked() & toCm.isChecked()){
             constant = 100;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if(frM.isChecked() & toFt.isChecked()){
             constant = 3.28084;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if(frM.isChecked() & toM.isChecked()) {
             constant = 1;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if(frM.isChecked() & toMl.isChecked()){
             constant = 0.000621371;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frM.isChecked() & toKl.isChecked()) {
             constant = 0.001;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         //Mile
         else if (frMl.isChecked() & toIn.isChecked()) {
             constant = 63360;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frMl.isChecked() & toCm.isChecked()) {
             constant = 160934;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frMl.isChecked() & toFt.isChecked()) {
             constant = 5280;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frMl.isChecked() & toM.isChecked()) {
             constant = 1609.34;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frMl.isChecked() & toMl.isChecked()) {
             constant = 1;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frMl.isChecked() & toKl.isChecked()) {
             constant = 1.60934;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         //Kilometer
         else if (frKl.isChecked() & toIn.isChecked()) {
             constant = 39370.1;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frKl.isChecked() & toCm.isChecked()) {
             constant = 100000;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frKl.isChecked() & toFt.isChecked()) {
             constant = 3280.84;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frKl.isChecked() & toM.isChecked()) {
             constant = 1000;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frKl.isChecked() & toMl.isChecked()) {
             constant = 0.621371;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }
         else if (frKl.isChecked() & toKl.isChecked()) {
             constant = 1;
             double value = number * constant;
             String result = String.format(Locale.getDefault(), "%.5f", value);
             convert.setText(result);
         }

         else
             Toast.makeText(getApplicationContext(), "Please Select a Method", Toast.LENGTH_SHORT).show();


    }

}

