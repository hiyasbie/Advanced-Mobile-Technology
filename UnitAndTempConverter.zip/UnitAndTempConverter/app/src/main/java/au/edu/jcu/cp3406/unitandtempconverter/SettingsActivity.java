package au.edu.jcu.cp3406.unitandtempconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

public class SettingsActivity extends AppCompatActivity {

    MainActivity main;

    RadioButton btnW, btnB,btnR,btnR3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        btnW = findViewById(R.id.btnWhite);
        btnB = findViewById(R.id.btnBlack);
        btnR = findViewById(R.id.btnRoad);
        btnR3 = findViewById(R.id.btnRoad3);

        if (btnW.isChecked()){

            main.toIn.setTextColor(Color.WHITE);
            main.toCm.setTextColor(Color.WHITE);
            main.toFt.setTextColor(Color.WHITE);
            main.toM.setTextColor(Color.WHITE);
            main.toMl.setTextColor(Color.WHITE);
            main.toKl.setTextColor(Color.WHITE);
            main.toCel.setTextColor(Color.WHITE);
            main.toFah.setTextColor(Color.WHITE);
            main.toKel.setTextColor(Color.WHITE);

        }else if (btnB.isChecked()){
            main.toIn.setTextColor(Color.BLACK);
            main.toCm.setTextColor(Color.BLACK);
            main.toFt.setTextColor(Color.BLACK);
            main.toM.setTextColor(Color.BLACK);
            main.toMl.setTextColor(Color.BLACK);
            main.toKl.setTextColor(Color.BLACK);
            main.toCel.setTextColor(Color.BLACK);
            main.toFah.setTextColor(Color.BLACK);
            main.toKel.setTextColor(Color.BLACK);
        }



    }

    public void backOnclick(View view) {
        super.onBackPressed();

    }
}
