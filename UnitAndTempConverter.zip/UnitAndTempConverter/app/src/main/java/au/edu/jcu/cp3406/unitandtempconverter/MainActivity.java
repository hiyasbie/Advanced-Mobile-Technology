package au.edu.jcu.cp3406.unitandtempconverter;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    TextView enter;
    RadioButton frIn, frCm, frFt, frM, frMl, frKl, frCel, frFah, frKel;
    TextView toIn, toCm, toFt, toM, toMl, toKl, toCel, toFah, toKel;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enter = findViewById(R.id.Entered);
        enterValue(enter);
    }

    public void enterValue(View view) {


        if (enter.isPressed()) {
            Toast.makeText(getApplicationContext(), "Hint: Type a Number and hit Backspace to Delete Numbers ", Toast.LENGTH_SHORT).show();
        } else

            Toast.makeText(getApplicationContext(), "Please Enter a Value", Toast.LENGTH_LONG).show();
    }

    @SuppressLint("SetTextI18n")
    public void convert(View view) {

        button = findViewById(R.id.convertButton);
        enter = findViewById(R.id.Entered);
        frIn = findViewById(R.id.fromIn);
        toIn = findViewById(R.id.toInch);
        frCm = findViewById(R.id.fromCm);
        toCm = findViewById(R.id.toCm);
        frFt = findViewById(R.id.fromFoot);
        toFt = findViewById(R.id.toFt);
        frM = findViewById(R.id.fromMeter);
        toM = findViewById(R.id.toM);
        frMl = findViewById(R.id.fromMile);
        toMl = findViewById(R.id.toMl);
        frKl = findViewById(R.id.fromKilometer);
        toKl = findViewById(R.id.toKl);
        frCel = findViewById(R.id.fromCel);
        toCel = findViewById(R.id.toCel);
        frFah = findViewById(R.id.fromFah);
        toFah = findViewById(R.id.toFah);
        frKel = findViewById(R.id.fromKel);
        toKel = findViewById(R.id.toKel);

        //For Unit Calculations
        double number = Double.parseDouble(enter.getText().toString());
        double valueIn, valueCm, valueFt, valueM, valueMl, valueKl;
        String result1, result2, result3, result4, result5, result6;

        //For Temperature Calculations
        double number2 = Double.parseDouble(enter.getText().toString());
        double number3 = Double.parseDouble(enter.getText().toString());

        // U N I T
        if (frIn.isChecked()) {
            valueIn = number * Converter.InIn;
            result1 = String.format(Locale.getDefault(), "%.2f", valueIn);
            toIn.setText(result1 + " In");

            valueCm = number * Converter.InCM;
            result2 = String.format(Locale.getDefault(), "%.2f", valueCm);
            toCm.setText(result2 + " Cm");

            valueFt = number * Converter.InFt;
            result3 = String.format(Locale.getDefault(), "%.3f", valueFt);
            toFt.setText(result3 + " Ft");

            valueM = number * Converter.InM;
            result4 = String.format(Locale.getDefault(), "%.5f", valueM);
            toM.setText(result4 + " M");

            valueMl = number * Converter.InMl;
            result5 = String.format(Locale.getDefault(), "%.5f", valueMl);
            toMl.setText(result5 + " Mi");

            valueKl = number * Converter.InKl;
            result6 = String.format(Locale.getDefault(), "%.5f", valueKl);
            toKl.setText(result6 + " Km");

            /*toCel.setText("˚C");
            toFah.setText("˚F");
            toKel.setText(" K");*/
            toCel.setText(null);
            toFah.setText(null);
            toKel.setText(null);

        } else if (frCm.isChecked()) {
            valueIn = number * Converter.CmIn;
            result1 = String.format(Locale.getDefault(), "%.2f", valueIn);
            toIn.setText(result1 + " In");

            valueCm = number * Converter.CmCm;
            result2 = String.format(Locale.getDefault(), "%.2f", valueCm);
            toCm.setText(result2 + " Cm");

            valueFt = number * Converter.CmFt;
            result3 = String.format(Locale.getDefault(), "%.2f", valueFt);
            toFt.setText(result3 + " Ft");

            valueM = number * Converter.CmM;
            result4 = String.format(Locale.getDefault(), "%.3f", valueM);
            toM.setText(result4 + " M");

            valueMl = number * Converter.CmMl;
            result5 = String.format(Locale.getDefault(), "%.5f", valueMl);
            toMl.setText(result5 + " Mi");

            valueKl = number * Converter.CmKl;
            result6 = String.format(Locale.getDefault(), "%.5f", valueKl);
            toKl.setText(result6 + " Km");

            toCel.setText(null);
            toFah.setText(null);
            toKel.setText(null);
        } else if (frFt.isChecked()) {

            valueIn = number * Converter.FtIn;
            result1 = String.format(Locale.getDefault(), "%.2f", valueIn);
            toIn.setText(result1 + " In");

            valueCm = number * Converter.FtCm;
            result2 = String.format(Locale.getDefault(), "%.2f", valueCm);
            toCm.setText(result2 + " Cm");

            valueFt = number * Converter.FtFt;
            result3 = String.format(Locale.getDefault(), "%.2f", valueFt);
            toFt.setText(result3 + " Ft");

            valueM = number * Converter.FtM;
            result4 = String.format(Locale.getDefault(), "%.3f", valueM);
            toM.setText(result4 + " M");

            valueMl = number * Converter.FtMl;
            result5 = String.format(Locale.getDefault(), "%.5f", valueMl);
            toMl.setText(result5 + " Mi");

            valueKl = number * Converter.FtKl;
            result6 = String.format(Locale.getDefault(), "%.5f", valueKl);
            toKl.setText(result6 + " Km");

            toCel.setText(null);
            toFah.setText(null);
            toKel.setText(null);
        } else if (frM.isChecked()) {

            valueIn = number * Converter.MIn;
            result1 = String.format(Locale.getDefault(), "%.2f", valueIn);
            toIn.setText(result1 + " In");

            valueCm = number * Converter.MCm;
            result2 = String.format(Locale.getDefault(), "%.2f", valueCm);
            toCm.setText(result2 + " Cm");

            valueFt = number * Converter.MFt;
            result3 = String.format(Locale.getDefault(), "%.2f", valueFt);
            toFt.setText(result3 + " Ft");

            valueM = number * Converter.MM;
            result4 = String.format(Locale.getDefault(), "%.2f", valueM);
            toM.setText(result4 + " M");

            valueMl = number * Converter.MMl;
            result5 = String.format(Locale.getDefault(), "%.5f", valueMl);
            toMl.setText(result5 + " Mi");

            valueKl = number * Converter.MKl;
            result6 = String.format(Locale.getDefault(), "%.5f", valueKl);
            toKl.setText(result6 + " Km");

            toCel.setText(null);
            toFah.setText(null);
            toKel.setText(null);
        } else if (frMl.isChecked()) {

            valueIn = number * Converter.MlIn;
            result1 = String.format(Locale.getDefault(), "%.2f", valueIn);
            toIn.setText(result1+ " In");

            valueCm = number * Converter.MlCm;
            result2 = String.format(Locale.getDefault(), "%.2f", valueCm);
            toCm.setText(result2+ " Cm");

            valueFt = number * Converter.MlFt;
            result3 = String.format(Locale.getDefault(), "%.2f", valueFt);
            toFt.setText(result3+" Ft");

            valueM = number * Converter.MlM;
            result4 = String.format(Locale.getDefault(), "%.2f", valueM);
            toM.setText(result4+ " M");

            valueMl = number * Converter.MlMl;
            result5 = String.format(Locale.getDefault(), "%.2f", valueMl);
            toMl.setText(result5+ " Mi");

            valueKl = number * Converter.MlKl;
            result6 = String.format(Locale.getDefault(), "%.2f", valueKl);
            toKl.setText(result6+ " Km");

            toCel.setText(null);
            toFah.setText(null);
            toKel.setText(null);
        } else if (frKl.isChecked()) {

            valueIn = number * Converter.KlIn;
            result1 = String.format(Locale.getDefault(), "%.2f", valueIn);
            toIn.setText(result1+ " In");

            valueCm = number * Converter.KlCm;
            result2 = String.format(Locale.getDefault(), "%.2f", valueCm);
            toCm.setText(result2+" Cm");

            valueFt = number * Converter.KlFt;
            result3 = String.format(Locale.getDefault(), "%.2f", valueFt);
            toFt.setText(result3+ " Ft");

            valueM = number * Converter.KlM;
            result4 = String.format(Locale.getDefault(), "%.2f", valueM);
            toM.setText(result4+ " M");

            valueMl = number * Converter.KlMl;
            result5 = String.format(Locale.getDefault(), "%.2f", valueMl);
            toMl.setText(result5+ " Mi");

            valueKl = number * Converter.KlKl;
            result6 = String.format(Locale.getDefault(), "%.2f", valueKl);
            toKl.setText(result6+ " Km");

            toCel.setText(null);
            toFah.setText(null);
            toKel.setText(null);

            //  T E M P E R A T U R E
        } else if (frCel.isChecked()) {
            number = Converter.same(number);
            String resultTemp = String.format(Locale.getDefault(), "%.2f", number);
            toCel.setText(resultTemp+"˚C");

            number2 = Converter.cel2fah(number2);
            String resultTemp2 = String.format(Locale.getDefault(), "%.2f", number2);
            toFah.setText(resultTemp2+"˚F");

            number3 = Converter.cel2Kel(number3);
            String resultTemp3 = String.format(Locale.getDefault(), "%.2f", number3);
            toKel.setText(resultTemp3+"K");

            toIn.setText(null);
            toCm.setText(null);
            toFt.setText(null);
            toM.setText(null);
            toMl.setText(null);
            toKl.setText(null);
        } else if (frFah.isChecked()) {
            number = Converter.fah2cel(number);
            String resultTemp = String.format(Locale.getDefault(), "%.2f", number);
            toCel.setText(resultTemp+"˚C");

            number2 = Converter.same(number2);
            String resultTemp2 = String.format(Locale.getDefault(), "%.2f", number2);
            toFah.setText(resultTemp2+"˚F");

            number3 = Converter.fah2Kel(number3);
            String resultTemp3 = String.format(Locale.getDefault(), "%.2f", number3);
            toKel.setText(resultTemp3+ "K");

            toIn.setText(null);
            toCm.setText(null);
            toFt.setText(null);
            toM.setText(null);
            toMl.setText(null);
            toKl.setText(null);
        } else if (frKel.isChecked()) {
            number = Converter.kel2cel(number);
            String resultTemp = String.format(Locale.getDefault(), "%.2f", number);
            toCel.setText(resultTemp + "°C");

            number2 = Converter.kel2fah(number2);
            String resultTemp2 = String.format(Locale.getDefault(), "%.2f", number2);
            toFah.setText(resultTemp2+"˚F");

            number3 = Converter.same(number3);
            String resultTemp3 = String.format(Locale.getDefault(), "%.2f", number3);
            toKel.setText(resultTemp3+"K");

            /*toIn.setText("Inch");
            toCm.setText("Centimeter");
            toFt.setText("Foot");
            toM.setText("Meter");
            toMl.setText("Mile");
            toKl.setText("Kilometer");*/
            toIn.setText(null);
            toCm.setText(null);
            toFt.setText(null);
            toM.setText(null);
            toMl.setText(null);
            toKl.setText(null);
        } else
            Toast.makeText(getApplicationContext(), "Please Select Unit From", Toast.LENGTH_LONG).show();

    }

    public void setOnclick(View view) {
        Intent intent = new Intent(getApplicationContext(),SettingsActivity.class);
        startActivity(intent);
    }
}
