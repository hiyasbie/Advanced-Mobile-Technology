package au.edu.jcu.cp3406.unitandtempconverter;

public class Converter {

    //Conversion Constants:
    //Inch
    static double InIn = 1, InCM = 2.54, InFt = 0.0833333, InM = 0.0254, InMl = 1.5783e-5, InKl = 2.54e-5;
    //Centimeter
    static double CmIn = 0.393701, CmCm = 1, CmFt = 0.0328084, CmM = 0.01, CmMl = 6.2137e-6, CmKl = 1e-5;
    //Foot
    static double FtIn = 12, FtCm = 30.48, FtFt = 1, FtM = 0.3048, FtMl = 0.000189394, FtKl = 0.0003048;
    //Meter
    static double MIn = 39.3701, MCm = 100, MFt = 3.28084, MM = 1, MMl = 0.000621371, MKl = 0.001;
    //Mile
    static double MlIn = 63360, MlCm = 160934, MlFt = 5280, MlM = 1609.34, MlMl = 1, MlKl = 1.60934;
    //Kilometer
    static double KlIn = 39370.1, KlCm = 100000, KlFt = 3280.84, KlM = 1000, KlMl = 0.621371, KlKl = 1;

    // Temperature Converter
    public static double cel2fah(double c) {
        return (c * 1.8) + 32;
    }

    public static double cel2Kel(double c) {
        return (c + 273.15);
    }

    public static double fah2cel(double f) {
        return (f - 32) / 1.8;
    }

    public static double fah2Kel(double f) {
        return ((f - 32) / 1.8) + 273.15;
    }

    public static double kel2cel(double k) {
        return (k - 273.15);
    }

    public static double kel2fah(double k) {
        return ((k - 273.15) * 1.8) + 32;
    }

    public static double same(double k) {
        return (k * 1);
    }


}
