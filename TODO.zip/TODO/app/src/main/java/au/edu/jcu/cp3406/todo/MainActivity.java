package au.edu.jcu.cp3406.todo;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    ArrayAdapter<String> adapter;
    ListView todoList;
    SharedPreferences dataSource;
    Set<String> newItems;
    Button button;
    ArrayList<String> arrPackage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        todoList = findViewById(R.id.todo);
        adapter = new ArrayAdapter<>(this, R.layout.item);
        todoList.setAdapter(adapter);
        adapter.addAll("buy milk", "wash car", "call mum");

        dataSource = getSharedPreferences("todo items", Context.MODE_PRIVATE);

        todoList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                TextView itemView = (TextView) view;
                adapter.remove(itemView.getText().toString());

                //remove item from dataSource when Item is Clicked.
                newItems = dataSource.getStringSet("items", new HashSet<String>());
                newItems.remove(itemView.getText().toString());
                dataSource.edit().clear().putStringSet("items", newItems).apply();
            }

        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add_item:
                //creates and uses an explicit intent that starts AddItemActivity when “Add item” is selected:
                Intent intent = new Intent(this, AddItemActivity.class);
                startActivity(intent);

                return true;
        }
        return super.onOptionsItemSelected(item);

    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.clear();
        newItems = dataSource.getStringSet("items", new HashSet<String>());
        assert newItems != null;
        adapter.addAll(newItems);

    }

    @Override
    protected void onStop() {

        newItems = dataSource.getStringSet("items", new HashSet<String>());
        newItems.equals(adapter);
        dataSource.edit().clear().putStringSet("items", newItems).apply();
        adapter.addAll(newItems);
        super.onStop();
    }

    //ADDED CLEAR/RESET BUTTON FOR MORE CONVENIENCE ON VERY LONG TODO LIST :)
    public void resetButton(View view) {
        button = findViewById(R.id.button);
        adapter.clear();
        newItems = dataSource.getStringSet("items", new HashSet<String>());
        newItems.clear();
        dataSource.edit().clear().putStringSet("items", newItems).apply();

    }

}
