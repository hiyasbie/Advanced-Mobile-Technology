package au.edu.jcu.cp3406.reflexchecker2;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;
import java.util.Random;

public class GameActivity extends AppCompatActivity {
    private Random random = new Random();
    String result;
    TextView display1;

    float start = System.nanoTime(); //Start Time in nanoseconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        setupDescription(R.id.task1, R.array.task1_descriptions);
        setupDescription(R.id.task2, R.array.task2_descriptions);
        setupDescription(R.id.task3, R.array.Extra_descriptions); // add Task for (EXTRA) Figure out a way to select drink names and fruit names once per game row
        display1 = findViewById(R.id.display);

        for (int i = 0; i < 5; i++) {
            addImage();
            addCheckboxes(R.array.drinks);
            addImage();
            addCheckboxes(R.array.fruits);
        }
    }

    private void setupDescription(int taskID, int arrayID) {
        TextView task = findViewById(taskID);
        String[] descriptions = getResources().getStringArray(arrayID);

        int i = random.nextInt(descriptions.length);
        task.setText(descriptions[i]);
    }

    private static final int[] drawables = {
            R.drawable.baseline_android_black_48,
            R.drawable.baseline_build_black_48,
            R.drawable.baseline_face_black_48,
            R.drawable.baseline_favorite_black_48
    };

    private void addImage() {
        ViewGroup gameRows = findViewById(R.id.game_rows);
        getLayoutInflater().inflate(R.layout.image, gameRows);

        View lastChild = gameRows.getChildAt(gameRows.getChildCount() - 1);
        ImageView image = lastChild.findViewById(R.id.image);

        int index = random.nextInt(drawables.length);
        image.setImageDrawable(getResources().getDrawable(drawables[index]));
    }

    private void addCheckboxes(int arrayID) {
        ViewGroup gameRows = findViewById(R.id.game_rows);
        getLayoutInflater().inflate(R.layout.checkboxes, gameRows);
        View lastChild = gameRows.getChildAt(gameRows.getChildCount() - 1);
        TableRow tableRow = lastChild.findViewById(R.id.checkboxes);
        String[] checkBoxName = getResources().getStringArray(arrayID);

        CheckBox checkBox1 = (CheckBox) tableRow.getChildAt(0);
        CheckBox checkBox2 = (CheckBox) tableRow.getChildAt(1);
        CheckBox checkBox3 = (CheckBox) tableRow.getChildAt(2);

        int index = random.nextInt(checkBoxName.length);
        checkBox1.setText(checkBoxName[index]);
        int index2 = random.nextInt(checkBoxName.length);
        checkBox2.setText(checkBoxName[index2]);
        int index3 = random.nextInt(checkBoxName.length);
        checkBox3.setText(checkBoxName[index3]);
    }

    @SuppressLint("SetTextI18n")
    //Setting up (EXTRA) Done button and Elapse Time using the System.nanoTime() in Done button
    public void doneButton(View view) {
        float end = System.nanoTime(); // End time in nanoseconds
        double total = (end - start) / 1000000000; // calculate elapse (total) time and set nanoseconds to seconds
        result = String.format(Locale.getDefault(), "%.3f", total); //set seconds to have .000 decimals
        display1.setText("Elapse time = " + result + "s"); //Display Elapse Time in the app after clicking Done button
    }
}








