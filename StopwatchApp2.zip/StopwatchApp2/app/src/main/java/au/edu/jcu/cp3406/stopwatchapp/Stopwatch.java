package au.edu.jcu.cp3406.stopwatchapp;

import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.Formatter;

public class Stopwatch {
    private int hours, minute, seconds;

    private Formatter formatter;

    public Stopwatch() {

        hours = 0;
        minute = 0;
        seconds = 0;
    }


    @Override
    @NonNull

    public String toString() {

        return String.format("%02d:%02d:%02d", hours, minute, seconds);

    }

    public void tick() {
        seconds += 1;
        if (seconds == 60) {
            seconds = 0;
            minute += 1;
            if (minute == 60) {
                minute = 0;
                hours += 1;
            }
        }
    }
    public void Reset(){
        seconds = 0;

    }
}
