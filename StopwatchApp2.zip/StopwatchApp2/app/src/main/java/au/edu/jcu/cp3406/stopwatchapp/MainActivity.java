package au.edu.jcu.cp3406.stopwatchapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Handler handler;
    private boolean isRunning;
    private Stopwatch stopwatch;
    private TextView time;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        stopwatch = new Stopwatch();
        time = findViewById(R.id.time);
    }

    private void enableStopwatch() {
        isRunning = true;
        handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                if(isRunning){

                    stopwatch.tick();
                    time.setText(stopwatch.toString());

                    handler.postDelayed(this, 1000);
                }
            }

        });


    }

    private void disableStopwatch(){

        isRunning = false;

    }
    public void buttonClicked(View view){

        if (isRunning){
            disableStopwatch();
        }
        else {
            enableStopwatch();
        }
    }
    public void reset(View view){
        stopwatch.Reset();
        TextView textView = (TextView) findViewById(R.id.time);
        time.setText(stopwatch.toString());


    }






}
